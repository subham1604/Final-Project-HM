import { Router } from '@angular/router';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  Router: any;

  constructor(public router:Router) { }
  
  login(uname:string, pword:string){
    if(uname==="sujit" && pword==="sujit"){
      return 200;
    }else{
      return 403;
    }
  }
   
  logout(){
    this.router.navigate(['login']);
  }

  addRoom(){
      this.router.navigate(['add-room']);
  }

  addhotel(){
    this.router.navigate(['add-hotel']);
  }
}
