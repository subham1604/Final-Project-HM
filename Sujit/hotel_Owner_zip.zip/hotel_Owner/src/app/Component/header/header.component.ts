import { Router, RouterModule } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  Router: any;

  constructor(private router:Router, private auth:AuthService) { }

  ngOnInit(): void {
  }

  goToHome(){
    this.Router.navigate(['home']);
  }

  logout(){
    this.auth.logout();
  }

  addRoom(){
    this.auth.addRoom();
  }

  addHotel(){
    this.auth.addhotel();
  }
}
