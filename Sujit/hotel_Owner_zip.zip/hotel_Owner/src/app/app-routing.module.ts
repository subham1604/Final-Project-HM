import { AddHotelComponent } from './Component/add-hotel/add-hotel.component';
import { HomeComponent } from './Component/home/home.component';
import { AddRoomComponent } from './Component/add-room/add-room.component';
import { LoginComponent } from './Component/login/login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './Component/header/header.component';

const routes: Routes = [
  {path:'',redirectTo:'login',pathMatch:'full'},
  {path:'login',component:LoginComponent},
  {path:'add-room', component:AddRoomComponent},
  {path:'header', component:HeaderComponent},
  {path:'home',component:HomeComponent},
  {path:'add-hotel',component:AddHotelComponent},
  {path:'**',component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
