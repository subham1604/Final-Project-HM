import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './Component/login/login.component';
import { AddRoomComponent } from './Component/add-room/add-room.component';
import { HomeComponent } from './Component/home/home.component';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from './Component/header/header.component';
import { AddHotelComponent } from './Component/add-hotel/add-hotel.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AddRoomComponent,
    HomeComponent,
    HeaderComponent,
    AddHotelComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
